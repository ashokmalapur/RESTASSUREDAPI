package com.restassured.testcases;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.restassured.constants.Constants;
import com.restassured.requests.pojo.PostProductRequest;
import com.restassured.responses.pojo.PostProductResponse;
import com.restassured.utils.RandomUtils;

import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetServerdefinition extends BaseTest{

	/*
	 * Please make sure you have followed these instruction to run the server on your localhost to execute these test
	 * https://github.com/BestBuy/api-playground
	 * ******************************************
	 * 	git clone https://github.com/bestbuy/api-playground/
	 *	cd api-playground
	 *	npm install
	 *	npm start
	 *  *****************************************
	 *  Load https://localhost:3030 on your browser
	 *  
	 */


	/*
	 * There should be a test case matching this test name in RUNMANAGER and TESTDATA sheet
	 * If there are multiple data lines in TESTDATA sheet, it will treated as iteration
	 * Mark Yes in RUNMANAGER and TESTDATA to run this test case
	 * @author M B RAVIKUMAR
	 */

	

	@Test
	public void postServerDefination() throws IOException {
		/*	sample request body
		 *   {
		 *   "name": "string",
			  "type": "string",
			  "price": 0,
			  "shipping": 0,
			  "upc": "string",
			  "description": "string",
			  "manufacturer": "string",
			  "model": "string",
			  "url": "string",
			  "image": "string",
			  "manufacturer":"string"
			}
		 */
System.out.println("TEST fROM ASHOK");
	

		Response response=	given()
				.filter(new RequestLoggingFilter(captor)) //This line is mandatory to log the request details to extent report
				.header("Content-Type","application/json")
				.header("Authorization","eyJhbGciOiJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGRzaWctbW9yZSNyc2Etc2hhNTEyIiwidHlwIjoiSldUIn0.eyJ1c2VyTmFtZSI6Im9wZW5hY2FzdHJvQGtwbWcuY29tIiwidXNlcklkIjoiOS4zMjI5MjEwMjcuMTI1OTIwMSIsImFwaUtleUlkIjoiNjcwLjI1NzYwMy4xMjU5MjAxIiwiYXBwbGljYXRpb25BY2Nlc3MiOiJBcGkiLCJuYmYiOjE2NDczNjMxNTAsImV4cCI6MTY3ODg5OTE1MCwiaXNzIjoiY2xhcml6ZW4uY29tIn0.dn-2Cx7sNld4If3vfU4BqZy1Lwgm6P6HVwcBpC8Nas-oTd3ASAgJnZopEDIjP8ho4oWHemeYDf1ua28igqrx59QmTuuKPfU-VAn1aoy76DiGmS0F5kDqJyxOLcUo48Xs23K0yk9sBbIYxpJqvTwWF-nhu_WGUbuDxSANyEcMvT7lDTQcqTvTgiYsPV__56Y1gVCk-5EIz_GktEK8u1CAtpbSAGe2J9ZPrpNcnoO8Dr1hEp7jX89TTfIxDY4TpnwXsL1MAZpXn1rGLozCkcaTSKiP2SroHYt28FYIrcTCRjH6yX8R4Mv0WXS2fKIBVagGM0MzNBVKeUnyEpLfIfGexw")
				.contentType(ContentType.JSON)
				.log()
				.all()
				.body(generateStringFromResource(Constants.SERVER_DEFINITION+"server_definition.json")) //passing mapobj in request body
				.post("https://api.clarizentb.com/v2.0/services/authentication/getServerDefinition");

		writeRequestAndResponseInReport(writer.toString(), response.prettyPrint());

		System.out.println(response.toString());
		//Assert status code
		response.then().statusCode(201);

		
		//Assert.assertEquals(response.jsonPath().get("name"), data.get("name"));


	}


	

}
